#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/ambrosetemidayobako/fvm/versions/3.13.6"
export "FLUTTER_APPLICATION_PATH=/Users/ambrosetemidayobako/Desktop/Dev/mobile-apps/fuodz-vendor"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=/Users/ambrosetemidayobako/Desktop/Dev/mobile-apps/fuodz-vendor/lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.7.10"
export "FLUTTER_BUILD_NUMBER=56"
export "DART_DEFINES=RkxVVFRFUl9XRUJfQVVUT19ERVRFQ1Q9dHJ1ZQ==,RkxVVFRFUl9XRUJfQ0FOVkFTS0lUX1VSTD1odHRwczovL3d3dy5nc3RhdGljLmNvbS9mbHV0dGVyLWNhbnZhc2tpdC9hNzk0Y2YyNjgxYzZjOWZlN2IyNjBlMGU4NGRlOTYyOThkYzljMThiLw=="
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=/Users/ambrosetemidayobako/Desktop/Dev/mobile-apps/fuodz-vendor/.dart_tool/package_config.json"
